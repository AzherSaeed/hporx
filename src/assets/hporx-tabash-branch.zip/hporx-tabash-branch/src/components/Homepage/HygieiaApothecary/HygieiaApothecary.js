import React from 'react'

const HygieiaApothecary = () => {
  return (
    <div>HygieiaApothecary</div>
  )
}

export default HygieiaApothecary