import styled from "styled-components";

export const FooterMainContainer = styled.div`
 ul{
     padding:0;
    list-style: none;
    li{
    a{
        text-decoration: none;
        color: black;
    }
}  
 }

`
