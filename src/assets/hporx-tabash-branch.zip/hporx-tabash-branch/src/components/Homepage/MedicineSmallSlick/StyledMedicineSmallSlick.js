import styled from "styled-components";

export const SmallMedicineContainerMain = styled.div`
margin-top:3rem

`
export const MedicineSmallImgContainer = styled.div`
padding: 2rem;
`
export const MedicineSmallImg = styled.img`
height:9rem;
object-fit:contain;
max-width:100%;
`
