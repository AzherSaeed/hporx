import React from 'react'

const InternationalOrganizations = () => {
  return (
    <div>InternationalOrganizations</div>
  )
}

export default InternationalOrganizations