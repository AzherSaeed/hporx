import React from 'react'

const FollowUs = () => {
  return (
    <div>FollowUs</div>
  )
}

export default FollowUs