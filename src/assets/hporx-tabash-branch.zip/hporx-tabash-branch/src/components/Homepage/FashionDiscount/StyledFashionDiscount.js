import styled from "styled-components";

export const FashionDiscountMainContainer=styled.div`
`
export const FashionDiscountImgContainer=styled.div`
padding: 2rem;
`
export const FashionDiscountImg=styled.img`
`