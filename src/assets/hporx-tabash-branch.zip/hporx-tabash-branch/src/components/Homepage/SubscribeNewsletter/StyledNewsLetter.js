import styled from "styled-components"


export const NewsLetterMainContianer = styled.div`
margin-top: 8rem;
h3{
    font-size: 3.5rem;
margin-bottom: 3rem;
}
`

export const NewsLetterImg = styled.img`

`
