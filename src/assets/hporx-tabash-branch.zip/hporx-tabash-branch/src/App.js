import './App.css';
import Homepage from './components/Homepage/Homepage';


function App() {
  return (
    <>
   <Homepage/>
    </>
  );
}

export default App;
